class User {
  late String email;
  late String password;
  User() {
    email = "";
    password = "";
  }
  User.takeInput({required this.email, required this.password});

  Map<String, dynamic> toJSON() {
    return {"email": email, "password": password};
  }
}

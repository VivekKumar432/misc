import 'package:flutter/material.dart';

import 'pages/homePage.dart';

void main() async {
  runApp(const MaterialApp(home: MyHomepage()));
}

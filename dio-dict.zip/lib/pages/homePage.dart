import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'package:reactive_forms_example/services/api_client.dart';

class MyHomepage extends StatefulWidget {
  const MyHomepage();

  @override
  State<MyHomepage> createState() => _MyHomepageState();
}

class _MyHomepageState extends State<MyHomepage> {
  late FormGroup form;
  bool isLoaded = false;
  bool isVisible = true;
  @override
  initState() {
    super.initState();
    form = FormGroup({
      'KeyWord': FormControl<String>(
          touched: true, value: '', validators: [Validators.required]),
    });
  }

  final ApiClient _client = ApiClient.getInstance();
  late List<dynamic> fetchedData;
  _getData(query) async {
    Response res = await _client
        .getData('https://api.dictionaryapi.dev/api/v2/entries/en/$query');
    fetchedData = res.data;
    if (fetchedData.isNotEmpty) {
      isLoaded = true;
      isVisible = !isVisible;
      print("success");
      setState(() {});
    }
  }

  Text _getText(String text, double fontsize, FontWeight fweight,
      {Color color = Colors.black}) {
    return Text(
      text,
      style: GoogleFonts.actor(
          textStyle:
              TextStyle(fontSize: fontsize, fontWeight: fweight, color: color)),
    );
  }

  TextEditingController fieldData = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ReactiveFormConfig(
      validationMessages: {
        ValidationMessage.required: (err) => "Field can't be empty"
      },
      child: Scaffold(
          appBar: AppBar(
            title: const Text('Dio Dictionary'),
            backgroundColor: Colors.teal,
          ),
          body: SingleChildScrollView(
            child: ReactiveForm(
              formGroup: form,
              child: Column(children: [
                Container(
                  padding: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width / 15,
                      right: MediaQuery.of(context).size.width / 15,
                      top: MediaQuery.of(context).size.height / 20),
                  child: ReactiveTextField(
                    controller: fieldData,
                    formControlName: 'KeyWord',
                    decoration: InputDecoration(
                        border: OutlineInputBorder(
                            borderSide:
                                const BorderSide(color: Colors.teal, width: 5),
                            borderRadius: BorderRadius.circular(10)),
                        focusedBorder: OutlineInputBorder(
                            borderSide:
                                const BorderSide(color: Colors.teal, width: 2),
                            borderRadius: BorderRadius.circular(10)),
                        labelText: "KeyWord",
                        hintText: "Enter a Keyword"),
                  ),
                ),
                ElevatedButton(
                    style: ButtonStyle(
                        backgroundColor:
                            MaterialStateProperty.all(Colors.teal)),
                    onPressed: () {
                      isVisible = !isVisible;
                      _getData(fieldData.text);
                    },
                    child: const Text('Submit')),
                _getText("Meaning :", 30, FontWeight.bold),
                Container(
                  padding: EdgeInsets.only(
                      left: MediaQuery.of(context).size.width / 15,
                      right: MediaQuery.of(context).size.width / 15,
                      top: MediaQuery.of(context).size.height / 80),
                  child: SizedBox(
                    height: MediaQuery.of(context).size.height / 1.5,
                    child: Visibility(
                      visible: isVisible,
                      replacement:
                          const Center(child: CircularProgressIndicator()),
                      child: isLoaded
                          ? _getText(
                              fetchedData[0]["meanings"][0]["definitions"][0]
                                  ["definition"],
                              20,
                              FontWeight.normal)
                          : const Text(""),
                    ),
                  ),
                )
              ]),
            ),
          )),
    );
  }
}

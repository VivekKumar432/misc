import 'dart:async';

import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:reactive_forms/reactive_forms.dart';
import 'package:reactive_forms_example/models/person.dart';
import 'package:reactive_forms_example/models/user.dart';
import 'package:reactive_forms_example/utils/network.dart';
import 'package:reactive_forms_example/utils/services/api_client.dart';
import 'package:reactive_forms_example/utils/toast.dart';
import 'dart:convert' as jsonconvert;

class Register extends StatefulWidget {
  Box<Person> box;
  Register(this.box);

  @override
  State<Register> createState() => _RegisterState();
}

class _RegisterState extends State<Register> {
  // 1st Step - Create Model
  late FormGroup form;
  bool isOnline = false;
  // Create the Object of Person Model
  Person _person = Person();
  late Stream<ConnectivityResult> sub;
  @override
  initState() {
    super.initState();
    _createModel();
    sub = checkConnectivity();
    sub.listen((ConnectivityResult result) {
      if (result == ConnectivityResult.wifi ||
          result == ConnectivityResult.mobile ||
          result == ConnectivityResult.ethernet) {
        // Online
        isOnline = true;
        createToast("U r Online...");
      } else {
        // Offline
        isOnline = false;
        createToast("U r Offline...");
      }
    }, onError: (err) => createToast("Some Error Occur...."));
  }

  @override
  dispose() {
    widget.box.close();
  }

  _createModel() {
    form = FormGroup({
      'email': FormControl<String>(
          touched: true,
          value: '',
          asyncValidators: [_isDupEmail],
          validators: [Validators.required, Validators.email]),
      'password': FormControl<String>(
          value: '', validators: [Validators.required, _isValidPassword]),
      'address': FormArray([])
    });
  }

  List<String> emails = ["amit@yahoo.com", "ram@yahoo.com"];
  Future<Map<String, dynamic>?> _isDupEmail(
      AbstractControl<dynamic> ctrl) async {
    String emailValue = ctrl.value.toString();
    await Future.delayed(Duration(seconds: 5));
    return emails.contains(emailValue) ? {"dupemail": "Duplicate email"} : null;
  }

  Map<String, dynamic>? _isValidPassword(AbstractControl<dynamic> ctrl) {
    String val = ctrl.value.toString();
    if (val.length >= 8 && val.length <= 25) {
      return null; // No Error
    } else {
      return {"invalidpwd": "Invalid Password"};
    }
  }

  _addAddress() {
    FormArray fm = form.control('address') as FormArray;
    fm.add(FormGroup({
      'city': FormControl(value: '', validators: [Validators.required]),
      'country': FormControl(value: '', validators: [Validators.required])
    }));
  }

  _submitForm() async {
    if (form.valid) {
      String email = form.control('email').value;
      String pwd = form.control('password').value;
      _person.email = email;
      _person.password = pwd;
      print("Person Object is $_person");
      // Online

      // Offline
      await widget.box.add(_person);
      setState(() {});
      //print("JSON is ${_person.toJSON()}");
      // Store the data in some object
      // and then either store in offline , Online store.
    } else {
      // form is invalid
      form.markAllAsTouched();
    }
  }

  ApiClient _client = ApiClient.getInstance();
  _doRegister() async {
    User user = User();
    user.email = useridCtrl.text;
    user.password = passwordCtrl.text;
    print("Data Rec " + user.email + " " + user.password);

    Response response = await _client.post(
        'https://jsonplaceholder.typicode.com/posts', user.toJSON());

    dynamic result = response.data; // Map
    print("Res $result ${result.runtimeType}");
    if (result["email"].length > 0) {
      createToast('User Register SuccessFully');
    } else {
      createToast("Not able to Register");
    }
  }

  _getData() async {
    Response res =
        await _client.getData('https://jsonplaceholder.typicode.com/users');
    List<dynamic> allData = res.data;
    print("Data Size is ${allData.length}");
  }

  TextEditingController useridCtrl = TextEditingController();
  TextEditingController passwordCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return ReactiveFormConfig(
      validationMessages: {
        ValidationMessage.required: (err) => "Field can't be empty"
      },
      child: Scaffold(
          appBar: AppBar(title: Text('Reactive Form')),
          body: SingleChildScrollView(
            child: ReactiveForm(
              formGroup: form,
              child: Column(children: [
                ReactiveTextField(
                  controller: useridCtrl,
                  //showErrors: (FormControl<String> ctrl) =>
                  //  ctrl.invalid && ctrl.dirty,
                  validationMessages: {
                    'dupemail': (err) => "Email is Duplicate ",
                    ValidationMessage.required: (err) => "Email is Required",
                    ValidationMessage.email: (err) => "Invalid Email"
                  },
                  formControlName: 'email',
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      labelText: "Email",
                      hintText: "Type Email here"),
                ),
                ReactiveTextField(
                  controller: passwordCtrl,
                  obscureText: true,
                  formControlName: 'password',
                  validationMessages: {
                    "invalidpwd": (err) => "Password is Invalid"
                  },
                  decoration: InputDecoration(
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      labelText: "Password",
                      hintText: "Type Password here"),
                ),
                ElevatedButton(
                    onPressed: () {
                      _addAddress();
                      //_submitForm();
                    },
                    child: Text('Add Address')),

                // Dynamic Fields
                ReactiveFormArray(
                    formArrayName: 'address',
                    builder: (context, FormArray formArr, Widget? child) {
                      FormArray addressList =
                          form.control('address') as FormArray;
                      List<Widget> list = addressList.controls
                          .map((control) => control as FormGroup)
                          .map((currentForm) {
                        return ReactiveForm(
                          formGroup: currentForm,
                          child: Column(
                            children: [
                              ReactiveTextField(
                                formControlName: 'city',
                                validationMessages: {
                                  ValidationMessage.required: (err) =>
                                      "City Can't Be Blank",
                                },
                                decoration: InputDecoration(
                                    labelText: 'City',
                                    border: OutlineInputBorder(
                                        borderRadius:
                                            BorderRadius.circular(10))),
                              ),
                              ReactiveTextField(
                                  formControlName: 'country',
                                  validationMessages: {
                                    ValidationMessage.required: (err) =>
                                        "Country Can't Be Blank",
                                  },
                                  decoration: InputDecoration(
                                      labelText: 'Country',
                                      border: OutlineInputBorder(
                                          borderRadius:
                                              BorderRadius.circular(10))))
                            ],
                          ),
                        );
                      }).toList();
                      return Wrap(children: list);
                    }),

                ElevatedButton(
                    onPressed: () {
                      _submitForm();
                    },
                    child: Text('Submit')),
                ElevatedButton(
                    onPressed: () {
                      _doRegister();
                    },
                    child: Text('Submit to Server')),
                ElevatedButton(
                    onPressed: () {
                      _getData();
                    },
                    child: Text('get data')),

                Container(
                    height: 200,
                    child: ValueListenableBuilder<Box<Person>>(
                      valueListenable: widget.box.listenable(),
                      builder: (context, Box<Person> box, Widget? widget) {
                        if (box.isEmpty) {
                          return Text('No Data in Box');
                        } else {
                          return ListView.builder(
                              itemCount: box.length,
                              itemBuilder: (context, int index) {
                                return Text(box.getAt(index)!.email);
                              });
                        }
                      },
                    ))
              ]),
            ),
          )),
    );
  }
}

import 'package:emi_calc/widgets/data.dart';
import 'package:emi_calc/widgets/field.dart';
import 'package:flutter/material.dart';

class Emi extends StatefulWidget {
  late double first_slider;
  late double second_slider;
  late double third_slider;

  @override
  _EmiState createState() => _EmiState();
}

class _EmiState extends State<Emi> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
          child: SingleChildScrollView(
        child: Column(
          children: [
            Field(
              label: 'Home Loan Amount',
              hint: 'Enter the Loan Amount',
              iconData: Icons.currency_rupee,
              range: 20000000,
              divisions: 200,
              index: 0,
            ),
            Field(
              label: 'Interest Rate',
              hint: 'Enter the Interest Rate ',
              iconData: Icons.percent,
              range: 20,
              divisions: 80,
              index: 1,
            ),
            Field(
              label: 'Loan Tenure',
              hint: 'Enter the Tenure',
              iconData: Icons.calendar_today,
              range: 30,
              divisions: 120,
              index: 2,
            ),
            DATA(
              hinttxt: 'Loan Amount',
            ),
            DATA(
              hinttxt: 'Interest',
            ),
            DATA(
              hinttxt: 'Total Payment',
            ),
          ],
        ),
      )),
    );
  }
}

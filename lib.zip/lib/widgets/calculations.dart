import 'package:emi_calc/widgets/data.dart';
import 'package:flutter/material.dart';

class CALCULATE extends StatelessWidget {
  late double principal;
  late double rate;
  late double tenure;
  late double data;

  CALCULATE({this.principal = 0, this.rate = 0, this.tenure = 0});

  _calculations() {
    if (principal != 0 && rate != 0 && tenure != 0) {
      data = ((principal * rate * (1 + rate) * tenure) /
          ((1 + rate) * tenure - 1));

      return data;
    }
  }

  @override
  Widget build(BuildContext context) {
    return DATA(
        // data2: data.toString(),
        );
  }
}

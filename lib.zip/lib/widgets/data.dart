import 'package:flutter/material.dart';

class DATA extends StatefulWidget {
  String data2;
  TextEditingController dt = TextEditingController();

  String hinttxt;
  DATA({this.data2 = '', this.hinttxt = ''});

  @override
  State<DATA> createState() => _DATAState();
}

class _DATAState extends State<DATA> {
  @override
  Widget build(BuildContext context) {
    widget.dt.text = widget.data2;
    return Container(
      margin: EdgeInsets.all(10),
      padding: EdgeInsets.all(10),
      decoration: BoxDecoration(
          color: Color.fromARGB(255, 1, 27, 48),
          borderRadius: BorderRadius.circular(10),
          boxShadow: const [
            BoxShadow(
              color: Colors.grey,
              blurStyle: BlurStyle.outer,
              blurRadius: 5,
            )
          ]),
      child: Column(
        children: [
          TextField(
            style: TextStyle(fontSize: 20, color: Colors.white),
            controller: widget.dt,
            textAlign: TextAlign.center,
            decoration: InputDecoration(
              hintText: widget.hinttxt,
              hintStyle: TextStyle(color: Colors.white),
              labelStyle: TextStyle(color: Colors.white),
              fillColor: Color.fromARGB(255, 4, 50, 87),
              filled: true,
              border:
                  OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
            ),
          )
        ],
      ),
    );
  }
}

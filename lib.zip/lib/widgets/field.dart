import 'package:emi_calc/widgets/calculations.dart';
import 'package:emi_calc/widgets/data.dart';
import 'package:flutter/material.dart';

class Field extends StatefulWidget {
  double str = 0.0;
  double result = 0.0;
  String label; //Text Field Title
  String hint; // Text Field Hint text
  IconData iconData; // contains Suffix icon in the textfield
  double range; // range of the slider
  double currentValue = 0.0; // the current or intitial value of the slider
  int divisions; // number of dividions of the slider
  late double end;
  int index;
  List<dynamic> ls = [" ", " ", " "];

  List<dynamic> ls2 = [];

  late int ind2;
  late double val;

  late double principal, rate, tenure;

  TextEditingController textfielddata = TextEditingController();
  Field(
      {required this.label,
      required this.iconData,
      required this.range,
      required this.divisions,
      required this.hint,
      required this.index});

  @override
  State<Field> createState() => _FieldState();
}

class _FieldState extends State<Field> {
  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
          color: Color.fromARGB(255, 1, 27, 48),
          borderRadius: BorderRadius.circular(10),
          boxShadow: const [
            BoxShadow(
              color: Colors.grey,
              blurStyle: BlurStyle.outer,
              blurRadius: 5,
            )
          ]),
      margin: EdgeInsets.all(5),
      padding: EdgeInsets.all(10),
      child: Column(
        children: [
          Row(
            children: [
              Expanded(
                flex: 1,
                child: TextField(
                  style: TextStyle(fontSize: 20, color: Colors.white),
                  controller: widget.textfielddata,
                  onChanged: (str) {
                    widget.str = double.parse(widget.textfielddata.text);
                    setState(() {});
                  },
                  textAlign: TextAlign.center,
                  decoration: InputDecoration(
                      hintText: widget.hint,
                      hintStyle: TextStyle(color: Colors.white),
                      labelText: widget.label,
                      labelStyle: TextStyle(color: Colors.white),
                      fillColor: Color.fromARGB(255, 4, 50, 87),
                      filled: true,
                      border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(10)),
                      suffixIcon: Icon(
                        widget.iconData,
                        color: Colors.white,
                      )),
                ),
              ),
            ],
          ),
          Slider(
            thumbColor: Colors.redAccent,
            activeColor: Colors.redAccent,
            inactiveColor: Colors.cyanAccent,
            divisions: widget.divisions,
            label: widget.currentValue.round().toString(),
            min: 0,
            max: widget.range,
            value: widget.currentValue,
            // onChangeEnd: (double end) {
            //   widget.end = end;
            //   widget.ls[widget.ind2] = widget.end;
            //   setState(() {});
            // },
            onChanged: (double currentvalue2) {
              widget.textfielddata.text = currentvalue2.toString();
              widget.currentValue = currentvalue2;
              widget.ind2 = widget.index;
              widget.val = currentvalue2;

              //widget.ls.insertAll(widget.ind2, widget.val);
              widget.ls[widget.ind2] = widget.val;
              DATA(data2: widget.ls[widget.ind2].toString());

              print(widget.ls);

              setState(() {});
            },
          ),
        ],
      ),
    );
  }
}

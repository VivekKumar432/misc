import 'package:http/http.dart' as http;

// API Call (Itunes)
class NewsClient {
  static Future<http.Response> getNewsByCountryName(String country) {
    final String URL =
        "https://newsapi.org/v2/top-headlines?country=$country&apiKey=36d6bcaa97b94bc19aed1a91c4e09f31";
    Future<http.Response> future = http.get(Uri.parse(URL));
    return future;
    // Here i do a network call
    // network calls are slow
    // Async (Non Blocking Call) + Future
  }
}

class SongModel {
  late String artistName;
  late String audioURL;
  late String imageURL;
  late String trackName;
  late bool isPlaying = false;

  // Param Constructor (UnNamed)
  SongModel(
      {required this.artistName,
      required this.audioURL,
      required this.imageURL,
      required this.trackName});

// Named Constructor
  SongModel.from(singleObject) {
    artistName = singleObject['artistName'];
    audioURL = singleObject['previewUrl'];
    trackName = singleObject['collectionName'];
    imageURL = singleObject['artworkUrl100'];
    // get obj and fill the song values
  }
}

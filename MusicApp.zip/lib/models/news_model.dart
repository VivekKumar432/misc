class NewsModel {
  late String author;
  late String title;
  late String description;
  late String url;
  late String urlImage;
  late String publishedAt;
  late String content;

  // Param Constructor (UnNamed)
  NewsModel(
      {required this.author,
      required this.title,
      required this.description,
      required this.url,
      required this.urlImage,
      required this.publishedAt,
      required this.content});

// Named Constructor
  NewsModel.from(singleObject) {
    author = singleObject['Author Name'];
    title = singleObject['Title'];
    description = singleObject['Description'];
    url = singleObject['url'];
    urlImage = singleObject['urlImage'];
    publishedAt = singleObject['PublishDate'];
    content = singleObject['content'];
    // get obj and fill the song values
  }
}

import 'package:flutter/material.dart';
import 'package:musicapp/models/news_model.dart';
import 'package:http/http.dart' as http;
import 'package:musicapp/repository/newsclient.dart';
import 'dart:convert' as convert;

class News extends StatefulWidget {
  const News({Key? key}) : super(key: key);

  @override
  State<News> createState() => _NewsState();
}

class _NewsState extends State<News> {
  //AudioPlayer audioPlayer = AudioPlayer();
  List<NewsModel> news = [];
  List<Widget> widgets = [];

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _getNews();
  }

  _getNews({String country = "us"}) {
    Future<http.Response> future = NewsClient.getNewsByCountryName(country);
    // Success Result / Success Response (JSON String)
    future.then((value) {
      print(" Data is ${value.body.runtimeType}"); // string
      var obj = convert.jsonDecode(value.body); // string to object
      print("Result is ${obj['articles']}");
      List<dynamic> list = obj['source'];
      news = convertObjectIntoNewsObjects(list);
      //print(obj['results'][3]['previewUrl']);
      //print(obj.runtimeType);
    }).
        // Fail Response (Network Error)
        catchError((err) => print("Failed Error is $err"));
  }

  List<NewsModel> convertObjectIntoNewsObjects(List list) {
    // Convert object into song list
    news = list.map((singleObject) {
      NewsModel news = NewsModel.from(singleObject);
      return news;
    }).toList();
    widgets = printNews();
    setState(() {});
    return news;
  }

  List<Widget> printNews() {
    return news.map((NewsModel news) {
      return ListTile(
        leading: Image.network(news.urlImage),
        title: Text(
          news.title,
          style: TextStyle(color: Colors.white),
        ),
        subtitle: Text(news.author, style: TextStyle(color: Colors.white)),
      );
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      body: SingleChildScrollView(child: Column(children: printNews())),
      appBar: AppBar(
          backgroundColor: Colors.grey.shade100,
          title: const Text(
            'News',
            style: TextStyle(color: Colors.black),
          )),
    );
  }
}
